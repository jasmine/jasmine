define([], function() {
  "use strict";

  // List all of your AMD specs here. amdSpecRunner.js will load and run all of these specs.
  return [
    "spec/amdSpec"
  ];
});
